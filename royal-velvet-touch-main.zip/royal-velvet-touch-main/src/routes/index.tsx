import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { motion, useScroll, useTransform, AnimatePresence } from "motion/react";
import {
  Sparkles, Shield, Droplets, Wrench, Lightbulb, Cog, Scissors, Waves,
  Truck, Building2, Star, Check, ChevronDown, ChevronRight, Phone, MessageCircle,
  ArrowUp, MapPin, Mail, Clock, Instagram, Facebook, Youtube, Menu, X, Crown,
} from "lucide-react";

import heroImg from "@/assets/hero.jpg";
import svcExterior from "@/assets/service-exterior.jpg";
import svcInterior from "@/assets/service-interior.jpg";
import svcCeramic from "@/assets/service-ceramic.jpg";
import svcPaint from "@/assets/service-paint.jpg";
import beforeImg from "@/assets/before.jpg";
import afterImg from "@/assets/after.jpg";
import g1 from "@/assets/gallery-1.jpg";
import g2 from "@/assets/gallery-2.jpg";
import g3 from "@/assets/gallery-3.jpg";
import g4 from "@/assets/gallery-4.jpg";
import g5 from "@/assets/gallery-5.jpg";
import g6 from "@/assets/gallery-6.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Royal Detailing LA — Luxury Auto Detailing in Los Angeles" },
      { name: "description", content: "Concours-level auto detailing, ceramic coating, paint correction and interior renewal for exceptional cars in Los Angeles." },
      { property: "og:title", content: "Royal Detailing LA — Luxury Auto Detailing" },
      { property: "og:description", content: "Where Los Angeles brings its most valued cars." },
      { property: "og:url", content: "/" },
    ],
    links: [{ rel: "canonical", href: "/" }],
  }),
  component: Index,
});

const NAV = [
  { label: "Services", href: "#services" },
  { label: "Gallery", href: "#gallery" },
  { label: "Reviews", href: "#reviews" },
  { label: "Pricing", href: "#pricing" },
  { label: "FAQ", href: "#faq" },
  { label: "About", href: "#about" },
  { label: "Contact", href: "#contact" },
];

function Index() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-background text-foreground">
      <ScrollProgress />
      <Navbar />
      <Hero />
      <TrustStrip />
      <Services />
      <BeforeAfter />
      <Gallery />
      <WhyUs />
      <Reviews />
      <Pricing />
      <Booking />
      <FAQ />
      <About />
      <Contact />
      <Footer />
      <FloatingActions />
    </div>
  );
}

/* ─────────── Scroll progress ─────────── */
function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  return (
    <motion.div
      style={{ scaleX: scrollYProgress }}
      className="fixed top-0 left-0 right-0 z-[60] h-[2px] origin-left bg-gradient-to-r from-gold-deep via-gold to-gold-soft"
    />
  );
}

/* ─────────── Navbar ─────────── */
function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className={`fixed top-0 inset-x-0 z-50 transition-all duration-500 ${scrolled ? "glass py-3" : "py-5 bg-transparent"}`}>
      <div className="mx-auto max-w-7xl px-6 flex items-center justify-between gap-6">
        <a href="#top" className="flex items-center gap-2 shrink-0">
          <Crown className="h-6 w-6 text-gold" />
          <span className="font-display text-xl tracking-wide">Royal <span className="gold-text">Detailing</span></span>
        </a>
        <nav className="hidden lg:flex items-center gap-8 text-sm text-muted-foreground">
          {NAV.map(n => (
            <a key={n.href} href={n.href} className="hover:text-gold transition-colors">{n.label}</a>
          ))}
        </nav>
        <a href="#booking" className="hidden lg:inline-flex btn-gold btn-gold-hover items-center gap-2 rounded-full px-5 py-2.5 text-sm">
          Book Now <ChevronRight className="h-4 w-4" />
        </a>
        <button className="lg:hidden text-foreground" onClick={() => setOpen(o => !o)} aria-label="Menu">
          {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="lg:hidden glass mx-4 mt-3 rounded-2xl p-6 flex flex-col gap-4"
          >
            {NAV.map(n => (
              <a key={n.href} href={n.href} onClick={() => setOpen(false)} className="text-lg text-foreground/90 hover:text-gold">{n.label}</a>
            ))}
            <a href="#booking" onClick={() => setOpen(false)} className="btn-gold btn-gold-hover text-center rounded-full px-5 py-3 mt-2">Book Now</a>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

/* ─────────── Hero ─────────── */
function Hero() {
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0]);

  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  useEffect(() => {
    const onMove = (e: MouseEvent) => {
      const nx = (e.clientX / window.innerWidth - 0.5) * 20;
      const ny = (e.clientY / window.innerHeight - 0.5) * 20;
      setTilt({ x: nx, y: ny });
    };
    window.addEventListener("mousemove", onMove);
    return () => window.removeEventListener("mousemove", onMove);
  }, []);

  return (
    <section id="top" ref={ref} className="relative h-[100svh] min-h-[720px] w-full overflow-hidden">
      <motion.div
        style={{ y, x: tilt.x * -1, scale: 1.1 }}
        className="absolute inset-0 will-change-transform"
      >
        <img src={heroImg} alt="Royal Detailing LA studio" width={1920} height={1200} className="h-full w-full object-cover" />
      </motion.div>
      <div className="absolute inset-0" style={{ background: "var(--gradient-hero)" }} />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_20%,transparent,oklch(0.08_0_0/0.6))]" />

      <motion.div style={{ opacity }} className="relative z-10 flex h-full flex-col items-center justify-center px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }}
          className="flex items-center gap-2 rounded-full glass px-4 py-1.5 text-xs uppercase tracking-[0.25em] text-gold-soft"
        >
          <Sparkles className="h-3.5 w-3.5" /> Est. 2012 · Los Angeles
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 1, delay: 0.15 }}
          className="mt-6 max-w-5xl text-5xl sm:text-6xl md:text-7xl lg:text-8xl leading-[1.02]"
        >
          Luxury Auto Detailing
          <span className="block gold-text italic">brought back to life.</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.35 }}
          className="mt-6 max-w-2xl text-base sm:text-lg text-muted-foreground"
        >
          Concours-level care for exceptional cars. Ceramic coating, paint correction,
          interior renewal — performed by hand in our climate-controlled studio.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9, delay: 0.5 }}
          className="mt-10 flex flex-col sm:flex-row items-center gap-4"
        >
          <a href="#booking" className="btn-gold btn-gold-hover rounded-full px-8 py-4 text-sm uppercase tracking-widest">Book Appointment</a>
          <a href="#contact" className="btn-ghost-gold btn-ghost-gold-hover rounded-full px-8 py-4 text-sm uppercase tracking-widest">Get Free Quote</a>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1, delay: 0.8 }}
          className="mt-10 flex flex-col items-center gap-2"
        >
          <div className="flex items-center gap-1 text-gold">
            {Array.from({ length: 5 }).map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
          </div>
          <p className="text-xs uppercase tracking-widest text-muted-foreground">Trusted by 500+ owners across Los Angeles</p>
        </motion.div>
      </motion.div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 text-muted-foreground">
        <span className="text-[10px] uppercase tracking-[0.4em]">Scroll</span>
        <div className="relative h-10 w-[1px] overflow-hidden bg-white/10">
          <span className="absolute top-0 left-0 h-2 w-[1px] bg-gold" style={{ animation: "scroll-dot 2s ease-in-out infinite" }} />
        </div>
      </div>
    </section>
  );
}

/* ─────────── Trust strip ─────────── */
function TrustStrip() {
  const items = ["Porsche", "Rolls-Royce", "Bentley", "Mercedes-Benz", "Ferrari", "Tesla", "Lamborghini", "McLaren"];
  return (
    <section className="border-y border-white/5 bg-black/40 py-8">
      <div className="mx-auto max-w-7xl px-6 flex flex-wrap items-center justify-center gap-x-12 gap-y-3 text-muted-foreground/70">
        <span className="text-[10px] uppercase tracking-[0.35em] text-gold-soft/70">Trusted by owners of</span>
        {items.map(i => (
          <span key={i} className="font-display text-lg sm:text-xl tracking-widest">{i}</span>
        ))}
      </div>
    </section>
  );
}

/* ─────────── Services ─────────── */
const SERVICES = [
  { icon: Sparkles, title: "Exterior Detail", desc: "Hand wash, decontamination, hand wax finish.", features: ["Foam bath", "Iron & tar removal", "Sealant"], time: "3–4 hrs", price: 149, img: svcExterior },
  { icon: Waves, title: "Interior Detail", desc: "Deep vacuum, steam, leather conditioning.", features: ["Steam sanitize", "Leather care", "Odor removal"], time: "3–5 hrs", price: 179, img: svcInterior },
  { icon: Shield, title: "Ceramic Coating", desc: "9H self-healing gloss lasting up to 7 years.", features: ["Multi-layer 9H", "Hydrophobic", "UV resistant"], time: "1–2 days", price: 899, img: svcCeramic, featured: true },
  { icon: Wrench, title: "Paint Correction", desc: "Multi-stage polish that removes swirls & scratches.", features: ["Depth gauge mapping", "3-stage cut", "Show-car gloss"], time: "1–2 days", price: 649, img: svcPaint },
  { icon: Lightbulb, title: "Headlight Restoration", desc: "Restore clarity and safety to yellowed lenses.", features: ["Wet sand", "Polish", "UV seal"], time: "1–2 hrs", price: 129 },
  { icon: Cog, title: "Engine Bay Detail", desc: "Meticulous cleaning and dressing under the hood.", features: ["Degrease", "Dress trims", "Concours finish"], time: "1–2 hrs", price: 149 },
  { icon: Scissors, title: "Scratch Removal", desc: "Targeted correction on scratches and swirl marks.", features: ["Spot correction", "Blend", "Seal"], time: "1 hr+", price: 99 },
  { icon: Droplets, title: "Wax & Sealant", desc: "Premium carnauba or synthetic protection.", features: ["Hand applied", "6 mo. protection", "Deep gloss"], time: "1–2 hrs", price: 119 },
  { icon: Truck, title: "Mobile Detailing", desc: "We come to you — home or office, anywhere in LA.", features: ["On-site service", "Self-contained", "By appointment"], time: "2–4 hrs", price: 199 },
  { icon: Building2, title: "Fleet Services", desc: "Custom programs for dealerships and collections.", features: ["Volume pricing", "Priority scheduling", "White-glove"], time: "Custom", price: 0 },
];

function Services() {
  return (
    <section id="services" className="relative py-32">
      <SectionHeading eyebrow="Services" title="Craft above the industry standard" sub="Every service performed by hand, in-studio, by trained detailers who treat your car like their own." />
      <div className="mx-auto mt-16 max-w-7xl px-6 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {SERVICES.map((s, i) => (
          <motion.article
            key={s.title}
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.6, delay: (i % 3) * 0.08 }}
            className={`group glass relative overflow-hidden rounded-3xl p-6 flex flex-col ${s.featured ? "ring-1 ring-gold/40" : ""}`}
          >
            {s.featured && <span className="absolute top-4 right-4 rounded-full bg-gold px-3 py-1 text-[10px] uppercase tracking-widest text-primary-foreground">Signature</span>}
            {s.img && (
              <div className="relative -mx-6 -mt-6 mb-6 h-44 overflow-hidden">
                <img src={s.img} alt={s.title} loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                <div className="absolute inset-0 bg-gradient-to-t from-card via-card/40 to-transparent" />
              </div>
            )}
            <div className="flex items-center gap-3">
              <div className="grid h-10 w-10 place-items-center rounded-xl bg-gold/10 text-gold ring-1 ring-gold/30">
                <s.icon className="h-5 w-5" />
              </div>
              <h3 className="text-xl">{s.title}</h3>
            </div>
            <p className="mt-3 text-sm text-muted-foreground">{s.desc}</p>
            <ul className="mt-4 space-y-1.5 text-sm">
              {s.features.map(f => (
                <li key={f} className="flex items-center gap-2 text-foreground/80"><Check className="h-3.5 w-3.5 text-gold" /> {f}</li>
              ))}
            </ul>
            <div className="mt-6 flex items-end justify-between border-t border-white/5 pt-4">
              <div>
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Duration</p>
                <p className="text-sm">{s.time}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] uppercase tracking-widest text-muted-foreground">From</p>
                <p className="text-2xl gold-text font-display">{s.price ? `$${s.price}` : "Custom"}</p>
              </div>
            </div>
            <a href="#booking" className="mt-5 inline-flex items-center justify-center gap-2 rounded-full border border-gold/40 py-2.5 text-sm text-gold-soft hover:bg-gold/10 transition">
              Book service <ChevronRight className="h-4 w-4" />
            </a>
          </motion.article>
        ))}
      </div>
    </section>
  );
}

/* ─────────── Section heading ─────────── */
function SectionHeading({ eyebrow, title, sub, center = true }: { eyebrow: string; title: string; sub?: string; center?: boolean }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
      transition={{ duration: 0.7 }}
      className={`mx-auto max-w-3xl px-6 ${center ? "text-center" : ""}`}
    >
      <p className="text-[10px] uppercase tracking-[0.4em] text-gold">{eyebrow}</p>
      <h2 className="mt-3 text-4xl sm:text-5xl md:text-6xl leading-tight">{title}</h2>
      {sub && <p className="mt-5 text-base text-muted-foreground">{sub}</p>}
      <div className="mx-auto mt-6 h-px w-24 hairline" />
    </motion.div>
  );
}

/* ─────────── Before / After slider ─────────── */
function BeforeAfter() {
  const [pos, setPos] = useState(50);
  const ref = useRef<HTMLDivElement>(null);
  const drag = useRef(false);
  useEffect(() => {
    const move = (clientX: number) => {
      const el = ref.current; if (!el) return;
      const rect = el.getBoundingClientRect();
      const p = ((clientX - rect.left) / rect.width) * 100;
      setPos(Math.min(100, Math.max(0, p)));
    };
    const onMove = (e: MouseEvent) => drag.current && move(e.clientX);
    const onTouch = (e: TouchEvent) => drag.current && move(e.touches[0].clientX);
    const stop = () => (drag.current = false);
    window.addEventListener("mousemove", onMove);
    window.addEventListener("touchmove", onTouch);
    window.addEventListener("mouseup", stop);
    window.addEventListener("touchend", stop);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("touchmove", onTouch);
      window.removeEventListener("mouseup", stop);
      window.removeEventListener("touchend", stop);
    };
  }, []);

  return (
    <section className="relative py-32">
      <SectionHeading eyebrow="Before / After" title="See the difference in detail" sub="Drag to reveal the transformation. Real cars, real results." />
      <div className="mx-auto mt-16 max-w-6xl px-6">
        <div
          ref={ref}
          className="relative aspect-[16/9] w-full overflow-hidden rounded-3xl select-none cursor-ew-resize glass"
          onMouseDown={() => (drag.current = true)}
          onTouchStart={() => (drag.current = true)}
        >
          <img src={afterImg} alt="After detailing" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 overflow-hidden" style={{ width: `${pos}%` }}>
            <img src={beforeImg} alt="Before detailing" loading="lazy" className="absolute inset-0 h-full w-full object-cover" style={{ width: `${100 / (pos / 100)}%`, maxWidth: "none" }} />
          </div>
          <div className="absolute top-0 bottom-0 w-[2px] bg-gold shadow-[0_0_20px_var(--gold)]" style={{ left: `${pos}%` }}>
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-12 w-12 rounded-full bg-gold text-primary-foreground grid place-items-center shadow-2xl">
              <ChevronRight className="h-5 w-5 -ml-3" />
              <ChevronRight className="h-5 w-5 rotate-180 -mr-3" />
            </div>
          </div>
          <span className="absolute top-4 left-4 rounded-full glass px-3 py-1 text-[10px] uppercase tracking-widest">Before</span>
          <span className="absolute top-4 right-4 rounded-full bg-gold px-3 py-1 text-[10px] uppercase tracking-widest text-primary-foreground">After</span>
        </div>
      </div>
    </section>
  );
}

/* ─────────── Gallery ─────────── */
const GALLERY = [
  { src: g1, cat: "Luxury" }, { src: g2, cat: "Exterior" }, { src: g3, cat: "Ceramic" },
  { src: g4, cat: "Interior" }, { src: g5, cat: "Luxury" }, { src: g6, cat: "Paint" },
  { src: svcExterior, cat: "Exterior" }, { src: svcInterior, cat: "Interior" }, { src: svcCeramic, cat: "Ceramic" },
];
const CATS = ["All", "Exterior", "Interior", "Ceramic", "Paint", "Luxury"];

function Gallery() {
  const [cat, setCat] = useState("All");
  const [lightbox, setLightbox] = useState<string | null>(null);
  const items = cat === "All" ? GALLERY : GALLERY.filter(g => g.cat === cat);
  return (
    <section id="gallery" className="relative py-32 bg-gradient-to-b from-background via-black/60 to-background">
      <SectionHeading eyebrow="Portfolio" title="A gallery of finished work" />
      <div className="mx-auto mt-10 flex flex-wrap justify-center gap-2 px-6">
        {CATS.map(c => (
          <button key={c} onClick={() => setCat(c)}
            className={`rounded-full px-5 py-2 text-xs uppercase tracking-widest transition ${cat === c ? "bg-gold text-primary-foreground" : "glass hover:text-gold"}`}
          >{c}</button>
        ))}
      </div>
      <div className="mx-auto mt-12 max-w-7xl px-6 columns-1 sm:columns-2 lg:columns-3 gap-5 [column-fill:_balance]">
        {items.map((it, i) => (
          <motion.button
            key={i} onClick={() => setLightbox(it.src)}
            initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
            className="mb-5 block w-full overflow-hidden rounded-2xl group relative"
          >
            <img src={it.src} alt="" loading="lazy" className="w-full transition-transform duration-700 group-hover:scale-110" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
              <span className="text-xs uppercase tracking-widest text-gold">{it.cat}</span>
            </div>
          </motion.button>
        ))}
      </div>
      <AnimatePresence>
        {lightbox && (
          <motion.div
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-[70] bg-black/95 backdrop-blur flex items-center justify-center p-6"
            onClick={() => setLightbox(null)}
          >
            <button className="absolute top-6 right-6 text-white" onClick={() => setLightbox(null)}><X className="h-8 w-8" /></button>
            <motion.img
              initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
              src={lightbox} alt="" className="max-h-[85vh] max-w-[90vw] rounded-2xl shadow-2xl"
            />
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}

/* ─────────── Why us ─────────── */
function Counter({ to, suffix = "" }: { to: number; suffix?: string }) {
  const [n, setN] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);
  useEffect(() => {
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !started.current) {
        started.current = true;
        const start = performance.now();
        const dur = 1600;
        const tick = (t: number) => {
          const p = Math.min(1, (t - start) / dur);
          const eased = 1 - Math.pow(1 - p, 3);
          setN(Math.round(to * eased));
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      }
    }, { threshold: 0.3 });
    if (ref.current) io.observe(ref.current);
    return () => io.disconnect();
  }, [to]);
  return <span ref={ref}>{n}{suffix}</span>;
}

function WhyUs() {
  const stats = [
    { n: 500, s: "+", label: "Cars Detailed" },
    { n: 5, s: "★", label: "Average Rating" },
    { n: 100, s: "%", label: "Satisfaction" },
    { n: 12, s: " yrs", label: "In Business" },
  ];
  const points = [
    { icon: Sparkles, t: "Premium Products", d: "Only certified ceramic coatings, pH-neutral soaps and finishing polishes." },
    { icon: Shield, t: "Fully Insured", d: "$2M coverage. Your car is protected the moment it enters our studio." },
    { icon: Clock, t: "Fast Turnaround", d: "Most services completed same-day. Ceramic in 24 hours." },
    { icon: Crown, t: "Master Detailers", d: "Trained on marques including Porsche, Rolls-Royce and Ferrari." },
  ];
  return (
    <section className="relative py-32">
      <SectionHeading eyebrow="Why Royal" title="Obsessive attention. Measurable results." />
      <div className="mx-auto mt-16 max-w-7xl px-6 grid grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map(st => (
          <div key={st.label} className="glass rounded-3xl p-8 text-center">
            <p className="font-display text-5xl md:text-6xl gold-text"><Counter to={st.n} suffix={st.s} /></p>
            <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">{st.label}</p>
          </div>
        ))}
      </div>
      <div className="mx-auto mt-8 max-w-7xl px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {points.map(p => (
          <div key={p.t} className="glass rounded-3xl p-6">
            <div className="grid h-11 w-11 place-items-center rounded-xl bg-gold/10 text-gold ring-1 ring-gold/30"><p.icon className="h-5 w-5" /></div>
            <h3 className="mt-4 text-xl">{p.t}</h3>
            <p className="mt-2 text-sm text-muted-foreground">{p.d}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ─────────── Reviews ─────────── */
const REVIEWS = [
  { name: "Alexander Reed", car: "Porsche 911 GT3", text: "Absolutely flawless. The car looked better than the day I picked it up from the dealer. Ceramic finish is like glass.", initial: "A" },
  { name: "Isabella Moreno", car: "Rolls-Royce Ghost", text: "White-glove service from booking to delivery. They treat every detail like it matters — because it does.", initial: "I" },
  { name: "Marcus Chen", car: "Tesla Model S Plaid", text: "Best in LA, hands down. Paint correction removed swirls I'd lived with for years. Genuine craftsmen.", initial: "M" },
  { name: "Sophia Laurent", car: "Bentley Continental", text: "The interior looks and smells brand new. Their leather treatment is unlike anything I've experienced.", initial: "S" },
];

function Reviews() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI(v => (v + 1) % REVIEWS.length), 6000);
    return () => clearInterval(t);
  }, []);
  return (
    <section id="reviews" className="relative py-32 bg-gradient-to-b from-black/40 via-background to-background">
      <SectionHeading eyebrow="Reviews" title="Words from our clients" />
      <div className="mx-auto mt-16 max-w-4xl px-6">
        <div className="relative glass rounded-3xl p-10 md:p-14 text-center overflow-hidden">
          <AnimatePresence mode="wait">
            <motion.div key={i}
              initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.5 }}
            >
              <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-gold to-gold-deep text-2xl font-display text-primary-foreground">{REVIEWS[i].initial}</div>
              <div className="mt-4 flex justify-center gap-1 text-gold">
                {Array.from({ length: 5 }).map((_, k) => <Star key={k} className="h-4 w-4 fill-current" />)}
              </div>
              <p className="mt-6 font-display text-2xl md:text-3xl leading-relaxed">"{REVIEWS[i].text}"</p>
              <p className="mt-6 text-sm text-foreground">{REVIEWS[i].name}</p>
              <p className="text-xs uppercase tracking-widest text-gold">{REVIEWS[i].car} · Verified</p>
            </motion.div>
          </AnimatePresence>
        </div>
        <div className="mt-8 flex justify-center gap-2">
          {REVIEWS.map((_, k) => (
            <button key={k} onClick={() => setI(k)}
              className={`h-1 rounded-full transition-all ${k === i ? "w-10 bg-gold" : "w-4 bg-white/20"}`} aria-label={`Review ${k+1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
}

/* ─────────── Pricing ─────────── */
const PLANS = [
  { name: "Essential", price: 199, desc: "Ideal for regular maintenance.", features: ["Hand exterior wash", "Interior vacuum", "Wheel & tire care", "Windows in & out"] },
  { name: "Premium", price: 449, desc: "Our most-loved package.", features: ["Everything in Essential", "Clay bar decontamination", "Hand wax finish", "Leather conditioning", "Engine bay dressing"], featured: true },
  { name: "Ultimate", price: 1299, desc: "The full concours treatment.", features: ["Everything in Premium", "2-stage paint correction", "5-year ceramic coating", "Interior deep steam", "Headlight restoration"] },
];

function Pricing() {
  return (
    <section id="pricing" className="relative py-32">
      <SectionHeading eyebrow="Packages" title="Choose the level of care" sub="Every package is customizable. Not sure what fits your car? Speak with a detailer." />
      <div className="mx-auto mt-16 max-w-7xl px-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        {PLANS.map((p, idx) => (
          <motion.div key={p.name}
            initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ duration: 0.6, delay: idx * 0.1 }}
            className={`glass relative rounded-3xl p-8 flex flex-col ${p.featured ? "ring-1 ring-gold/50 md:-translate-y-4 md:scale-105" : ""}`}
            style={p.featured ? { boxShadow: "var(--shadow-gold)" } : undefined}
          >
            {p.featured && <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-gold px-4 py-1 text-[10px] uppercase tracking-widest text-primary-foreground">Recommended</span>}
            <p className="text-[10px] uppercase tracking-[0.35em] text-gold">{p.name}</p>
            <div className="mt-4 flex items-baseline gap-2">
              <span className="font-display text-6xl">${p.price}</span>
            </div>
            <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
            <ul className="mt-8 space-y-3 flex-1">
              {p.features.map(f => (
                <li key={f} className="flex items-start gap-3 text-sm">
                  <Check className="mt-0.5 h-4 w-4 text-gold shrink-0" /> <span>{f}</span>
                </li>
              ))}
            </ul>
            <a href="#booking" className={`mt-8 rounded-full text-center py-3 text-sm uppercase tracking-widest transition ${p.featured ? "btn-gold btn-gold-hover" : "btn-ghost-gold btn-ghost-gold-hover"}`}>
              Book {p.name}
            </a>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

/* ─────────── Booking ─────────── */
function Booking() {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({ name: "", phone: "", email: "", make: "", model: "", year: "", service: "Premium Detail", date: "", time: "", notes: "" });

  const priceMap: Record<string, number> = {
    "Essential": 199, "Premium Detail": 449, "Ultimate": 1299, "Ceramic Coating": 899, "Paint Correction": 649, "Interior Deep Clean": 179,
  };
  const estimate = priceMap[form.service] ?? 199;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <section id="booking" className="relative py-32 bg-gradient-to-b from-background via-black/70 to-background">
      <SectionHeading eyebrow="Book" title="Reserve your appointment" sub="We'll confirm within one business hour." />
      <div className="mx-auto mt-16 max-w-5xl px-6">
        <div className="glass rounded-3xl p-8 md:p-12">
          <AnimatePresence mode="wait">
            {sent ? (
              <motion.div key="ok" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
                <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-gold/10 ring-1 ring-gold/40">
                  <Check className="h-10 w-10 text-gold" />
                </div>
                <h3 className="mt-6 text-3xl">Booking received</h3>
                <p className="mt-3 text-muted-foreground">Thank you, {form.name || "friend"}. A detailer will confirm shortly at {form.phone || form.email || "your contact"}.</p>
                <button onClick={() => setSent(false)} className="mt-8 btn-ghost-gold btn-ghost-gold-hover rounded-full px-6 py-3 text-sm">Book another</button>
              </motion.div>
            ) : (
              <motion.form key="form" onSubmit={submit} className="grid grid-cols-1 md:grid-cols-2 gap-5" initial={{ opacity: 1 }}>
                <Field label="Full name" value={form.name} onChange={v => setForm({...form, name: v})} required />
                <Field label="Phone" value={form.phone} onChange={v => setForm({...form, phone: v})} required />
                <Field label="Email" type="email" value={form.email} onChange={v => setForm({...form, email: v})} required />
                <Field label="Year" value={form.year} onChange={v => setForm({...form, year: v})} />
                <Field label="Vehicle make" value={form.make} onChange={v => setForm({...form, make: v})} />
                <Field label="Vehicle model" value={form.model} onChange={v => setForm({...form, model: v})} />
                <div className="md:col-span-2">
                  <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Service</label>
                  <select value={form.service} onChange={e => setForm({...form, service: e.target.value})}
                    className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3 focus:border-gold outline-none">
                    {Object.keys(priceMap).map(o => <option key={o}>{o}</option>)}
                  </select>
                </div>
                <Field label="Preferred date" type="date" value={form.date} onChange={v => setForm({...form, date: v})} />
                <Field label="Preferred time" type="time" value={form.time} onChange={v => setForm({...form, time: v})} />
                <div className="md:col-span-2">
                  <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-2">Notes</label>
                  <textarea rows={3} value={form.notes} onChange={e => setForm({...form, notes: e.target.value})}
                    className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3 focus:border-gold outline-none resize-none" />
                </div>
                <div className="md:col-span-2 flex flex-col sm:flex-row items-center justify-between gap-4 mt-2 pt-6 border-t border-white/10">
                  <div>
                    <p className="text-[10px] uppercase tracking-widest text-muted-foreground">Estimated price</p>
                    <p className="font-display text-4xl gold-text">${estimate}</p>
                  </div>
                  <button type="submit" className="btn-gold btn-gold-hover rounded-full px-10 py-4 text-sm uppercase tracking-widest">Confirm Booking</button>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

function Field({ label, value, onChange, type = "text", required = false }: { label: string; value: string; onChange: (v: string) => void; type?: string; required?: boolean }) {
  return (
    <div>
      <label className="block text-[10px] uppercase tracking-widest text-muted-foreground mb-2">{label}</label>
      <input type={type} required={required} value={value} onChange={e => onChange(e.target.value)}
        className="w-full rounded-xl bg-black/40 border border-white/10 px-4 py-3 focus:border-gold outline-none transition" />
    </div>
  );
}

/* ─────────── FAQ ─────────── */
const FAQS = [
  { q: "How long does a full detail take?", a: "Most complete details take 3 to 6 hours. Ceramic coating requires 24 hours in the studio for proper curing." },
  { q: "Do I need to book an appointment?", a: "Yes. We work by appointment to give every car our full attention. Weekend slots book two weeks in advance." },
  { q: "Do you offer ceramic coating?", a: "We install professional-grade 9H ceramic coatings with warranties from 2 to 7 years, applied by certified installers." },
  { q: "How often should I detail my vehicle?", a: "Daily drivers benefit from a maintenance detail every 6–8 weeks. Garage-kept collections every 3 months." },
  { q: "Are you insured?", a: "Yes — fully insured with $2M coverage. All detailers are trained and background-checked." },
  { q: "Do you offer mobile service?", a: "Absolutely. Our mobile detailing units serve Beverly Hills, Malibu, Hollywood, and surrounding areas." },
];

function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="relative py-32">
      <SectionHeading eyebrow="FAQ" title="Answers, quickly" />
      <div className="mx-auto mt-16 max-w-3xl px-6 space-y-3">
        {FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={i} className="glass rounded-2xl overflow-hidden">
              <button onClick={() => setOpen(isOpen ? null : i)} className="w-full flex items-center justify-between gap-4 p-6 text-left">
                <span className="text-lg">{f.q}</span>
                <ChevronDown className={`h-5 w-5 text-gold shrink-0 transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              <AnimatePresence>
                {isOpen && (
                  <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.3 }}>
                    <p className="px-6 pb-6 text-sm text-muted-foreground">{f.a}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          );
        })}
      </div>
    </section>
  );
}

/* ─────────── About ─────────── */
function About() {
  return (
    <section id="about" className="relative py-32">
      <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div initial={{ opacity: 0, x: -30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
          <p className="text-[10px] uppercase tracking-[0.4em] text-gold">Our Story</p>
          <h2 className="mt-3 text-4xl md:text-5xl">A studio built for cars that deserve more.</h2>
          <div className="mt-4 h-px w-24 hairline" />
          <p className="mt-6 text-muted-foreground">
            Royal Detailing LA was founded in 2012 by a small team of enthusiasts who believed the industry had forgotten what
            care actually looks like. Today we operate from a climate-controlled studio in Hollywood, serving a discreet
            clientele of collectors, executives, and drivers who expect the very best.
          </p>
          <p className="mt-4 text-muted-foreground">
            Every car is inspected, documented, and treated by a lead detailer. No shortcuts, no rotating hands, no rushed
            deliveries. Just the finish your car was designed to wear.
          </p>
          <div className="mt-8 grid grid-cols-3 gap-6">
            {[{n:"12", l:"Years"},{n:"5", l:"Detailers"},{n:"1", l:"Studio"}].map(x => (
              <div key={x.l}>
                <p className="font-display text-4xl gold-text">{x.n}</p>
                <p className="text-xs uppercase tracking-widest text-muted-foreground">{x.l}</p>
              </div>
            ))}
          </div>
        </motion.div>
        <motion.div initial={{ opacity: 0, x: 30 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}
          className="grid grid-cols-2 gap-4">
          <img src={g1} alt="Studio" loading="lazy" className="rounded-2xl object-cover h-full" />
          <div className="space-y-4">
            <img src={svcCeramic} alt="Ceramic" loading="lazy" className="rounded-2xl object-cover" />
            <img src={g4} alt="Interior" loading="lazy" className="rounded-2xl object-cover" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}

/* ─────────── Contact ─────────── */
function Contact() {
  return (
    <section id="contact" className="relative py-32 bg-gradient-to-b from-background via-black/60 to-background">
      <SectionHeading eyebrow="Contact" title="Visit the studio" />
      <div className="mx-auto mt-16 max-w-7xl px-6 grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass rounded-3xl p-8 space-y-6">
          <ContactRow icon={MapPin} title="Studio" text="1450 N La Brea Ave, Los Angeles, CA 90028" />
          <ContactRow icon={Phone} title="Call" text="(323) 555-0142" />
          <ContactRow icon={Mail} title="Email" text="concierge@royaldetailingla.com" />
          <ContactRow icon={Clock} title="Hours" text="Mon – Sat  ·  8:00 AM – 7:00 PM" />
          <div className="flex gap-3 pt-2">
            {[Instagram, Facebook, Youtube].map((Ic, i) => (
              <a key={i} href="#" className="grid h-11 w-11 place-items-center rounded-full glass hover:bg-gold/10 hover:text-gold transition"><Ic className="h-4 w-4" /></a>
            ))}
          </div>
        </div>
        <div className="glass rounded-3xl overflow-hidden min-h-[400px]">
          <iframe
            title="Map"
            src="https://maps.google.com/maps?q=1450%20N%20La%20Brea%20Ave%20Los%20Angeles&t=&z=14&ie=UTF8&iwloc=&output=embed"
            className="w-full h-full min-h-[400px] grayscale contrast-125 opacity-90"
            loading="lazy"
          />
        </div>
      </div>
    </section>
  );
}

function ContactRow({ icon: Ic, title, text }: { icon: React.ComponentType<{className?: string}>; title: string; text: string }) {
  return (
    <div className="flex items-start gap-4">
      <div className="grid h-11 w-11 place-items-center rounded-xl bg-gold/10 text-gold ring-1 ring-gold/30 shrink-0"><Ic className="h-5 w-5" /></div>
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-widest text-muted-foreground">{title}</p>
        <p className="mt-1">{text}</p>
      </div>
    </div>
  );
}

/* ─────────── Footer ─────────── */
function Footer() {
  return (
    <footer className="border-t border-white/5 bg-black/60 pt-20 pb-8">
      <div className="mx-auto max-w-7xl px-6 grid grid-cols-1 md:grid-cols-4 gap-10">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            <Crown className="h-6 w-6 text-gold" />
            <span className="font-display text-xl">Royal <span className="gold-text">Detailing</span></span>
          </div>
          <p className="mt-4 text-sm text-muted-foreground max-w-sm">
            Concours-level auto detailing in the heart of Los Angeles. By appointment only.
          </p>
          <p className="mt-6 text-[10px] uppercase tracking-widest text-gold">Newsletter</p>
          <form className="mt-3 flex gap-2 max-w-sm">
            <input type="email" placeholder="you@domain.com" className="flex-1 rounded-full bg-black/50 border border-white/10 px-4 py-2.5 text-sm focus:border-gold outline-none" />
            <button className="btn-gold btn-gold-hover rounded-full px-5 py-2.5 text-sm">Join</button>
          </form>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gold">Explore</p>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            {NAV.map(n => <li key={n.href}><a href={n.href} className="hover:text-gold">{n.label}</a></li>)}
          </ul>
        </div>
        <div>
          <p className="text-[10px] uppercase tracking-widest text-gold">Contact</p>
          <ul className="mt-4 space-y-2 text-sm text-muted-foreground">
            <li>1450 N La Brea Ave</li>
            <li>Los Angeles, CA 90028</li>
            <li>(323) 555-0142</li>
            <li>Mon – Sat · 8AM – 7PM</li>
          </ul>
        </div>
      </div>
      <div className="mx-auto max-w-7xl px-6 mt-14 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
        <p>© {new Date().getFullYear()} Royal Detailing LA. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="hover:text-gold">Privacy</a>
          <a href="#" className="hover:text-gold">Terms</a>
          <a href="#" className="hover:text-gold">Gift Cards</a>
        </div>
      </div>
    </footer>
  );
}

/* ─────────── Floating actions ─────────── */
function FloatingActions() {
  const [show, setShow] = useState(false);
  useEffect(() => {
    const on = () => setShow(window.scrollY > 400);
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);
  return (
    <div className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3">
      <AnimatePresence>
        {show && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="grid h-12 w-12 place-items-center rounded-full glass hover:text-gold" aria-label="Scroll to top"
          >
            <ArrowUp className="h-5 w-5" />
          </motion.button>
        )}
      </AnimatePresence>
      <a href="tel:+13235550142" className="grid h-12 w-12 place-items-center rounded-full glass hover:text-gold" aria-label="Call"><Phone className="h-5 w-5" /></a>
      <a href="https://wa.me/13235550142" target="_blank" rel="noopener" className="grid h-12 w-12 place-items-center rounded-full bg-[#25D366] text-white shadow-lg hover:scale-110 transition" aria-label="WhatsApp"><MessageCircle className="h-5 w-5" /></a>
      <a href="#booking" className="btn-gold btn-gold-hover rounded-full px-5 py-3 text-xs uppercase tracking-widest hidden sm:inline-block">Book</a>
    </div>
  );
}
